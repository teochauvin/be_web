
class jsonFileTrack: 

    def __init__(self, name, path): 

        self.name = name
        self.path = path

        self.trajectoryCount = 0 

    def writeSat(self, name, timeStart, nPoints, timeSep, position, infoSat, last_bool): 

        ch = ""

        ch += "{\n"

        ch += '\t\"nameSate\": \"%s\",\n'%name
        ch += '\t\"timeStart\": \"%s\",\n'%timeStart
        ch += '\t\"npoints\": \"%s\",\n'%nPoints
        ch += '\t\"timeSep\": \"%s\",\n'%timeSep
        ch += self.get_position(position)
        ch += self.get_infos(infoSat)

        if last_bool == False: 
            ch += "},\n"
        else: 
            ch += "}\n"

        return ch

    def write(self, name_list, timeStart, nPoints, timeSep, position_list, infoSats, N):

        with open(self.path, 'w') as f: 

            f.write('{\n')
            f.write('\"nameFile\": \"satellite_tle\",\n')
            f.write('\"satellites_infos\": [\n')

            for i in range(N): 
                
                if i < N-1: 
                    f.write(self.writeSat(name_list[i], timeStart, nPoints, timeSep, position_list[i], infoSats[i], False))
                else: 
                    f.write(self.writeSat(name_list[i], timeStart, nPoints, timeSep, position_list[i],infoSats[i], True))

            f.write(']\n')
            f.write('}')

    def get_position(self, position): 

        block = ""

        # open object
        block += '\t\"angularPosition\": [\n'

        for i in range(len(position)): 
            line_str = ('\t\t{\"longitude\": %s, \"latitude\": %s, \"height\": %s}'%(position[i][0], position[i][1], position[i][2]))
                
            block += line_str
            if i != len(position)-1:
                block += ',\n'
            else: 
                block += "\n"

        block += '],\n'

        return block

    def get_infos(self, infoSat): 

        block = ""

        block += '\t\"infoSats\": {\n'

        for i in range(len(infoSat)): 
            line_str = ('\t\t\"category\": "%s",\n \t\t\"orbite\": "%s",\n \t\t\"longitude\": %s,\n \t\t\"latitude\": %s,\n \t\t\"altitude\": %s,\n \t\t\"inclinaison\": %s,\n  \t\t\"longitudeNoeud\": %s,\n \t\t\"anomalieMoyenne\": %s,\n \t\t\"semiMajorAxis\": %s,\n \t\t\"semiMinorAxis\": %s,\n \t\t\"arg\": %s,\n \t\t\"source\": "%s",\n \t\t\"pays\": %s}\n'%(
               infoSat["category"],infoSat["orbite"],infoSat["longitude"],infoSat["latitude"],infoSat["altitude"], infoSat["inclinaison"], infoSat["longitudeNoeud"], infoSat["anomalieMoyenne"], infoSat["semiMajorAxis"],infoSat["semiMinorAxis"], infoSat["arg"], infoSat["source"], infoSat["idPays"]))

        block += line_str
        if i != len(infoSat)-1:
            block += ',\n'
        else: 
            block += "\n"

        return block