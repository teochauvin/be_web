import mysql.connector 
import hashlib
from mysql.connector import errorcode
from ..config import DB_SERVER

# connexion au serveur de BDD
def connexion():
    cnx= ""
    
    try:
        cnx= mysql.connector.connect(**DB_SERVER)
        error= None

    except mysql.connector.Error as err:
        error= err
        if err.errno== errorcode.ER_ACCESS_DENIED_ERROR:
            print("Mauvais login ou mot de passe")
        elif err.errno== errorcode.ER_BAD_DB_ERROR:
            print("La Base de données n'existe pas.")
        else:
            print(err)

    return cnx, error # error: remonte problème connexion# fermeture de la connexion au serveur de BDDdefclose_bd(cursor, cnx):cursor.close()cnx.close()

# fermeture de la connexion au serveur de BDD
def close_bd(cursor, cnx):
    cursor.close()
    cnx.close()

# MEMBRES

def get_membreData():

    try:
        cnx, error = connexion()
        if error is not None: 
            return error, None # Problème connexion BDD
        
        cursor= cnx.cursor(dictionary=True)
        sql= "SELECT * FROM identification"

        cursor.execute(sql)

        listeMembre= cursor.fetchall()

        close_bd(cursor, cnx)
        msg = "OKmembres"
    
    except mysql.connector.Error as err:
        listeMembre= None
        msg = "Failedgetmembres data : {}".format(err)

    return msg, listeMembre

def del_membreData(idUser): 

    try: 
        cnx, error = connexion()
        if error is not None: 
            return error, None

        cursor = cnx.cursor(dictionary=True)
        sql = "DELETE FROM identification WHERE idUser={}".format(idUser)

        cursor.execute(sql)
        cnx.commit()

        close_bd(cursor, cnx)
        msg = "suppMembreOK"
    
    except mysql.connector.Error as err: 
        msg = "Failedgetmembres data : {}".format(err)

    return msg

def add_membreData(nom, prenom, mail, login, mdp, statut, avatar): 

    try: 
        cnx, error = connexion()
        if error is not None: 
            return error, None 

        cursor = cnx.cursor(dictionary = True) 

        h = hashlib.sha256()
        h.update(mdp.encode("utf-8")) 
        mdp_hash = h.hexdigest()

        sql = "INSERT INTO identification (nom, prenom, mail, login, MotPasse, statut, avatar) VALUES (%s, %s, %s, %s, %s, %s, %s)"
        param=(nom, prenom, mail, login, mdp_hash, statut, avatar)
        cursor.execute(sql, param)

        lastId = cursor.lastrowid
        cnx.commit()

        close_bd(cursor, cnx)
        msg = "addMembreOK" 

    except mysql.connector.Error as err: 

        msg = "Fail add member : {}".format(err) 
        lastId = None

    return msg, lastId 

def verifAuthData(login, mdp):

    try:
        cnx, error = connexion()
        if error is not None:
            return error, None
        
        cursor = cnx.cursor(dictionary=True)

        h = hashlib.sha256()
        h.update(mdp.encode("utf-8")) 
        mdp_hash = h.hexdigest()

        print(mdp_hash)

        sql = "SELECT * FROM identification WHERE login=%s and motPasse=%s"
        param=(login, mdp_hash)
        cursor.execute(sql, param)

        user = cursor.fetchone()
        close_bd(cursor, cnx)
        
        msg = "authOK"
    
    except mysql.connector.Error as err:
        user = None
        msg = "Failed get Auth data : {}".format(err)

    return msg, user


# SATELLITE

def get_SatelliteDataWhere(where): 
    try:
        cnx, error = connexion()
        if error is not None: 
            return error, None # Problème connexion BDD
        
        cursor= cnx.cursor(dictionary=True)
        sql= "SELECT * FROM satellites WHERE {}".format(where)

        cursor.execute(sql)

        listeSats = cursor.fetchall()

        close_bd(cursor, cnx)
        msg = "OKsatsWhere"
    
    except mysql.connector.Error as err:
        listeSats = None
        msg = "FailedgetSat data : {}".format(err)

    return msg, listeSats

def get_SatelliteData(): 

    try:
        cnx, error = connexion()
        if error is not None: 
            return error, None # Problème connexion BDD
        
        cursor= cnx.cursor(dictionary=True)
        sql= "SELECT * FROM satellites"

        cursor.execute(sql)

        listeSats = cursor.fetchall()

        close_bd(cursor, cnx)
        msg = "OKsats"
    
    except mysql.connector.Error as err:
        listeSats= None
        msg = "FailedgetSat data : {}".format(err)

    return msg, listeSats


# réécrire add et update séparément pour la correction
def addUp_SatData(dst, sessionId, paysId=1): 

    try:
        cnx, error = connexion()
        if error is not None: 
            return error, None # Problème connexion BDD
        
        cursor1 = cnx.cursor(dictionary=True)

        sql1 = "SELECT * FROM satellites WHERE nomSatellite=%s;"
        param1 = (dst[0],)
        cursor1.execute(sql1, param1) 

        yovar = cursor1.fetchall() 
        cnx.commit()

        close_bd(cursor1, cnx)

        if len(yovar) == 0: 

            try:
                cnx, error = connexion()
                if error is not None: 
                    return error, None # Problème connexion BDD

            
                cursor2 = cnx.cursor(dictionary=True)
                sql2 = "INSERT IGNORE INTO satellites (nomSatellite, category, orbite, longitude, latitude, altitude, inclinaison, longitudeNoeud, anomalieMoyenne, semiMajorAxis, semiMinorAxis, arg, source, idUser, idPays, tle) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
                param2 = (dst[0],dst[1],dst[2],dst[3],dst[4],dst[5],dst[6],dst[7],dst[8],dst[9],dst[10],dst[11],dst[12], sessionId, paysId, dst[13])

                cursor2.execute(sql2, param2)
                cnx.commit()

                close_bd(cursor2, cnx)

                msg = "OKAddSat"

            except mysql.connector.Error as err:
                msg = "FailedaddSat data : {}".format(err)

        else: 
            try:
                cnx, error = connexion()
                if error is not None: 
                    return error, None # Problème connexion BDD

                cursor2 = cnx.cursor()
                sql2 = "UPDATE satellites SET category=\'{}\',orbite=\'{}\',longitude={},latitude={},altitude={},inclinaison={},longitudeNoeud={},anomalieMoyenne={},semiMajorAxis={},semiMinorAxis={},arg={},source=\'{}\', tle=\'{}\' WHERE nomSatellite=\'{}\';".format(dst[1],dst[2],dst[3],dst[4],dst[5],dst[6],dst[7],dst[8],dst[9],dst[10],dst[11],dst[12], dst[13], dst[0])

                cursor2.execute(sql2)
                cnx.commit()

                close_bd(cursor2, cnx)

                msg = "OKUpSat"

            except mysql.connector.Error as err:
                msg = "FailedUpSat data : {}".format(err)

    except mysql.connector.Error as err:
        msg = "FailedaddSat data : {}".format(err)

    return msg

def del_SatData(idSat): 

    try: 
        cnx, error = connexion()
        if error is not None: 
            return error, None

        cursor = cnx.cursor(dictionary=True)
        sql = "DELETE FROM satellites WHERE idSatellite={}".format(idSat)

        cursor.execute(sql)
        cnx.commit()

        close_bd(cursor, cnx)
        msg = "suppSatOK"
    
    except mysql.connector.Error as err: 
        msg = "FailedSuppSat data : {}".format(err)

    return msg

def del_AllSatData(): 

    try: 
        cnx, error = connexion()
        if error is not None: 
            return error, None

        cursor = cnx.cursor(dictionary=True)
        sql = "DELETE FROM assoGroupesSatellites"

        cursor.execute(sql)
        cnx.commit()

        sql2 = "DELETE FROM groupes"

        cursor.execute(sql2)
        cnx.commit()

        sql3 = "DELETE FROM satellites"

        cursor.execute(sql3)
        cnx.commit()

        close_bd(cursor, cnx)
        msg = "suppAllSatOK"
    
    except mysql.connector.Error as err: 
        msg = "FailedSuppSat data : {}".format(err)

    return msg

# PAYS 

def get_paysData():

    try:
        cnx, error = connexion()
        if error is not None: 
            return error, None # Problème connexion BDD
        
        cursor= cnx.cursor(dictionary=True)
        sql= "SELECT * FROM pays"

        cursor.execute(sql)

        listePays = cursor.fetchall()

        close_bd(cursor, cnx)
        msg = "OKPays"
    
    except mysql.connector.Error as err:
        listeMembre= None
        msg = "FailedgetSat data : {}".format(err)

    return msg, listePays

# GROUPES   

def get_groupesData(): 

    try:
        cnx, error = connexion()
        if error is not None: 
            return error, None # Problème connexion BDD
        
        cursor= cnx.cursor(dictionary=True)
        sql= "SELECT * FROM groupes"

        cursor.execute(sql)

        listeGroupes = cursor.fetchall()

        close_bd(cursor, cnx)
        msg = "OKGroupes"
    
    except mysql.connector.Error as err:
        listeMembre= None
        msg = "FailedgetSat data : {}".format(err)

    return msg, listeGroupes

def get_groupesDataWhere(where):

    try:
        cnx, error = connexion()
        if error is not None: 
            return error, None # Problème connexion BDD
        
        cursor= cnx.cursor(dictionary=True)
        sql= "SELECT * FROM groupes WHERE {}".format(where)

        cursor.execute(sql)

        listeGroupes = cursor.fetchall()

        close_bd(cursor, cnx)
        msg = "OKgroupes"
    
    except mysql.connector.Error as err:
        listeGroupes = None
        msg = "FailedgetGroupes data : {}".format(err)

    return msg, listeGroupes

def add_groupesData(nom, couleur): 

    try: 
        cnx, error = connexion()
        if error is not None: 
            return error, None 

        cursor = cnx.cursor(dictionary = True) 

        sql = "INSERT INTO groupes (nomGroupe, colorGroupe) VALUES (%s, %s)"
        param=(nom, couleur)
        cursor.execute(sql, param)

        lastId = cursor.lastrowid
        cnx.commit()

        close_bd(cursor, cnx)
        msg = "addGroupeOK" 

    except mysql.connector.Error as err: 

        msg = "Fail add member : {}".format(err) 
        print(msg)
        lastId = None

    return msg, lastId 

def del_groupesData(idGroupe): 
    """Il faut que l'association groupe -- sats soit vide"""
    
    try: 
        cnx, error = connexion()
        if error is not None: 
            return error, None

        cursor = cnx.cursor(dictionary=True)
        sql = "DELETE FROM groupes WHERE idGroupe={}".format(idGroupe)

        cursor.execute(sql)
        cnx.commit()

        close_bd(cursor, cnx)
        msg = "suppGroupeOK"
    
    except mysql.connector.Error as err: 
        msg = "Failedgetmembres data : {}".format(err)

    return msg

def del_allGroupesData():

    try: 
        cnx, error = connexion()
        if error is not None: 
            return error, None

        cursor = cnx.cursor(dictionary=True)
        sql = "DELETE FROM assoGroupesSatellites"

        cursor.execute(sql)
        cnx.commit()

        sql2 = "DELETE FROM groupes"
        cursor.execute(sql2)
        cnx.commit()

        close_bd(cursor, cnx)
        msg = "suppAllGroupeOK"
    
    except mysql.connector.Error as err: 
        msg = "Failedgetmembres data : {}".format(err)

    return msg

# ASSOCIATIONS

def get_groupeIdWhere(where): 
    """ Retourne l'id du groupe nommé ... """

    try:
        cnx, error = connexion()
        if error is not None: 
            return error, None # Problème connexion BDD
        
        cursor= cnx.cursor(dictionary=True)
        sql= "SELECT idGroupe FROM groupes WHERE {}".format(where)

        cursor.execute(sql)

        listeGroupes = cursor.fetchall()

        close_bd(cursor, cnx)
        msg = "OKgroupes"
    
    except mysql.connector.Error as err:
        listeMembre= None
        msg = "FailedgetSat data : {}".format(err)

    return msg, listeGroupes[0]

def get_satelliteIdWhere(where): 
    """ Retourne l'id du satellite nommé ... """

    listeSatellites = []

    try:
        cnx, error = connexion()
        if error is not None: 
            return error, None # Problème connexion BDD
        
        cursor= cnx.cursor(dictionary=True)
        sql= "SELECT idSatellite FROM satellites WHERE {}".format(where)

        cursor.execute(sql)

        listeSatellites = cursor.fetchall()

        close_bd(cursor, cnx)
        msg = "OKsatsID"
    
    except mysql.connector.Error as err:
        listeSatellites= None
        msg = "FailedgetSat data : {}".format(err)

    return msg, listeSatellites

def add_assoGroupeSatellite(groupe, liste_sats): 

    try: 
        cnx, error = connexion()
        if error is not None: 
            return error, None 

        cursor = cnx.cursor(dictionary = True) 

        for sat_id in liste_sats:

            sql = "INSERT INTO assoGroupesSatellites (idGroupe, idSatellite) VALUES (%s, %s)"%(groupe, sat_id["idSatellite"])

            cursor.execute(sql)

            cnx.commit()

        close_bd(cursor, cnx)
        msg = "addAssoOK" 

    except mysql.connector.Error as err: 

        msg = "Fail add member : {}".format(err) 
        print(msg)

    return msg

def get_assoGroupeSatellite(): 

    try:
        cnx, error = connexion()
        if error is not None: 
            return error, None # Problème connexion BDD
        
        cursor= cnx.cursor(dictionary=True)
        sql= "SELECT * FROM assoGroupeSatellite"

        cursor.execute(sql)

        listeAssoGroupeSat = cursor.fetchall()

        close_bd(cursor, cnx)
        msg = "OKAsso"
    
    except mysql.connector.Error as err:
        listeMembre= None
        msg = "FailedgetSat data : {}".format(err)

    return msg, listeAssoGroupeSat

def get_assGroupeSatelliteWhere(where): 

    try:
        cnx, error = connexion()
        if error is not None: 
            return error, None # Problème connexion BDD
        
        cursor= cnx.cursor(dictionary=True)
        sql= "SELECT * FROM assoGroupesSatellites WHERE {}".format(where)

        cursor.execute(sql)

        listeAssoGroupeSat = cursor.fetchall()

        close_bd(cursor, cnx)
        msg = "OKAssoWhere"
    
    except mysql.connector.Error as err:
        listeAssoGroupeSat = None
        msg = "FailedgetSat data : {}".format(err)

    return msg, listeAssoGroupeSat

def del_assoGroupeSatellite(idGroupe): 

    try: 
        cnx, error = connexion()
        if error is not None: 
            return error, None

        cursor = cnx.cursor(dictionary=True)
        sql = "DELETE FROM assoGroupesSatellites WHERE idGroupe={}".format(idGroupe)

        cursor.execute(sql)
        cnx.commit()

        close_bd(cursor, cnx)
        msg = "suppAssoOK"
    
    except mysql.connector.Error as err: 
        msg = "Failedgetmembres data : {}".format(err)

    return msg

def get_assoGroupeSatelliteWhere(where_groupe): 

    try:
        cnx, error = connexion()
        if error is not None: 
            return error, None # Problème connexion BDD
        
        cursor= cnx.cursor(dictionary=True)
        sql= "SELECT idSatellite FROM assoGroupesSatellites WHERE idGroupe={}".format(where_groupe)

        cursor.execute(sql)

        listeSat = cursor.fetchall()

        close_bd(cursor, cnx)
        msg = "OKSatWhereGroupe"
    
    except mysql.connector.Error as err:
        listeSat= None
        msg = "FailedgetSat data : {}".format(err)

    return msg, listeSat